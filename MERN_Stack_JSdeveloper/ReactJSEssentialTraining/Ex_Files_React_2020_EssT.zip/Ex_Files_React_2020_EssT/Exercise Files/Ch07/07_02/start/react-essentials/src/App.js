import React from "react";
import "./App.css";

function App() {
  if (data) {
    return (
      <div>
        <h1>Hello React Testing Library</h1>
      </div>
    );
  }

  return <div>No Data Available</div>;
}

export default App;
