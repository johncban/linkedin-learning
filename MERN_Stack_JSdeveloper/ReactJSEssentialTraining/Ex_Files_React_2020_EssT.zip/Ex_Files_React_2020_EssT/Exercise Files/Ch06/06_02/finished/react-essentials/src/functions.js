export function timesTwo(a) {
  return a * b;
}
