import React from "react";
import ReactDOM from "react-dom";
import "./index.css";

ReactDOM.render(
  <ul>
    <li>Monday</li>
    <li>Tuesday</li>
    <li>Wednesday</li>
  </ul>,
  document.getElementById("root")
);
